branch = u'fix'
nightly = False
official = True
version = u'7.7.1.24030407'
version_name = u'32bit Sensation'
